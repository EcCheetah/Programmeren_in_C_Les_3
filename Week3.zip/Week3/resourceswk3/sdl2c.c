/*
Copyright (C) 2020
Sander Gieling
Inholland University of Applied Sciences at Alkmaar, the Netherlands

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation, 
Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

// Artwork bibliography
// --------------------
// Reticle taken from here:
// https://flyclipart.com/download-png#printable-crosshair-targets-clip-art-clipart-675613.png
// Blorp taken from here:
// https://opengameart.org/content/animated-top-down-survivor-player
// Desert floor tiling taken from here:
// https://www.flickr.com/photos/maleny_steve/8899498324/in/photostream/

#include <stdio.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h> // for IMG_Init and IMG_LoadTexture
#include <math.h> // for atan() function

#define SCREEN_WIDTH				1024
#define SCREEN_HEIGHT				576
#define PI							3.14159265358979323846
#define PLAYER_MAX_SPEED			6.0f
#define PLAYER_DECELERATION			0.9f
// Tiles were added in this version:
#define TILE_SIZE_IN_PIXELS			256
#define VIEWPORT_WIDTH_IN_TILES  (SCREEN_WIDTH / TILE_SIZE_IN_PIXELS)
#define VIEWPORT_HEIGHT_IN_TILES (SCREEN_HEIGHT / TILE_SIZE_IN_PIXELS)

typedef struct _mouse_ {
	int x;
	int y;
	SDL_Texture *txtr_reticle;
} mouse;

typedef struct _player_ {
	int x;
	int y;
	float speed_x;
	float speed_y;
	int up;
	int down;
	int left;
	int right;
	float angle;
	SDL_Texture *txtr_player;
} player;

typedef enum _keystate_ {
	UP = 0,
	DOWN = 1
} keystate;

void handle_key(SDL_KeyboardEvent *keyevent, keystate updown,
	player *tha_playa);
void process_input(player *tha_playa, mouse *tha_mouse);
// This function was updated to hold a REFERENCE POINT to the top-left
// corner of the viewport, expressed in `world coordinates':
void update_player(player *tha_playa, mouse *tha_mouse, 
	SDL_Point *topleft);
void proper_shutdown(void);
SDL_Texture *load_texture(char *filename);
void blit(SDL_Texture *texture, int x, int y, int center);
void blit_angled(SDL_Texture *txtr, int x, int y, float angle);
float get_angle(int x1, int y1, int x2, int y2);
// These next two have been added to handle tiling & viewport management
void handle_camera(SDL_Point *topleft, player *tha_playa);
void draw_viewport(SDL_Texture *txtr_bg_repeat, SDL_Point *topleft);

SDL_Window *window = NULL;
SDL_Renderer *renderer = NULL;

int main(int argc, char *argv[])
{
	(void)argc;
	(void)argv;
	
	player blorp = {(SCREEN_WIDTH / 2), (SCREEN_HEIGHT / 2), 0.0f, 0.0f,
		UP, UP, UP, UP, 0.0, NULL};
	mouse mousepointer;
	// Added a texture for the background tile (repeating tile) and a
	// coordinate keeping track of the center of the viewport, to keep
	// Blorp there:
	SDL_Texture *txtr_background;
	// This top left coordinate is in `world coordinates'. More on the 
	// different coordinate systems here:
	// http://math.hws.edu/graphicsbook/c2/s1.html
	// and especially here:
	// http://math.hws.edu/graphicsbook/c2/s3.html
	SDL_Point viewport_topleft = {0, 0};
	
	unsigned int window_flags = 0;
	unsigned int renderer_flags = SDL_RENDERER_ACCELERATED;
	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		printf("Couldn't initialize SDL: %s\n", SDL_GetError());
		exit(1);
	}
	window = SDL_CreateWindow("Blorp is going to F U UP!", 
		SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, 
		SCREEN_HEIGHT, window_flags);
	if (window == NULL)
	{
		printf("Failed to create window -- Error: %s\n",
			SDL_GetError());
		exit(1);
	}
	renderer = SDL_CreateRenderer(window, -1, renderer_flags);
	if (renderer == NULL)
	{
		printf("Failed to create renderer -- Error: %s\n",
			SDL_GetError());
		exit(1);
	}
	IMG_Init(IMG_INIT_PNG);
	blorp.txtr_player = load_texture("gfx/idlebody/survivor-idle_handgun_0.png");
	mousepointer.txtr_reticle = load_texture("gfx/reticle.png");
	// NEW: Added precaching of the background texture:
	txtr_background = load_texture("gfx/bg256.png");
	SDL_ShowCursor(0);
	
	while (1)
	{
		SDL_SetRenderDrawColor(renderer, 120, 144, 156, 255);
		SDL_RenderClear(renderer);

		process_input(&blorp, &mousepointer);
		
		// Game logic now also takes the viewport top-left and the
		// camera (viewport) handling into account:
		update_player(&blorp, &mousepointer, &viewport_topleft);
		handle_camera(&viewport_topleft, &blorp);
		
		// Backbuffer update now also draws viewport (i.e. tiles in the 
		// background):
		draw_viewport(txtr_background, &viewport_topleft);
		// For a more in-depth explanation of what is happening to the 
		// player coordinates to keep them centered, see the 
		// `update_player()' function...
		blit_angled(blorp.txtr_player, blorp.x - viewport_topleft.x, 
			blorp.y - viewport_topleft.y, blorp.angle);
		blit(mousepointer.txtr_reticle, mousepointer.x, 
			mousepointer.y, 1);
		
		SDL_RenderPresent(renderer);
		SDL_Delay(16);
	}

	return 0;
}

void handle_key(SDL_KeyboardEvent *keyevent, keystate updown, 
	player *tha_playa)
{
	if (keyevent->repeat == 0)
	{
		if (keyevent->keysym.scancode == SDL_SCANCODE_W)
		{
			tha_playa->up = updown;
		}
		if (keyevent->keysym.scancode == SDL_SCANCODE_S)
		{
			tha_playa->down = updown;
		}
		if (keyevent->keysym.scancode == SDL_SCANCODE_A)
		{
			tha_playa->left = updown;
		}
		if (keyevent->keysym.scancode == SDL_SCANCODE_D)
		{
			tha_playa->right = updown;
		}
	}
}

void process_input(player *tha_playa, mouse *tha_mouse)
{
	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
			case SDL_QUIT:
				proper_shutdown();
				exit(0);
				break;
			case SDL_KEYDOWN:
				if (event.key.keysym.scancode == SDL_SCANCODE_ESCAPE)
				{
					proper_shutdown();
					exit(0);
				}
				else
				{
					handle_key(&event.key, DOWN, tha_playa);
				}
				break;
			case SDL_KEYUP:
				handle_key(&event.key, UP, tha_playa);
				break;
			default:
				break;
		}
	}
	SDL_GetMouseState(&tha_mouse->x, &tha_mouse->y);
}

// This function was changed to always make the player appear to be
// in the center of the screen. For that to work, you need to know
// the `world coordinate' of your viewport's top-left pixel. Let's call
// that the `topleft':
void update_player(player *tha_playa, mouse *tha_mouse, 
	SDL_Point *topleft)
{
	if (tha_playa->up)
	{
		tha_playa->y -= (int)PLAYER_MAX_SPEED;
	}
	if (tha_playa->down)
	{
		tha_playa->y += (int)PLAYER_MAX_SPEED;
	}
	if (tha_playa->left)
	{
		tha_playa->x -= (int)PLAYER_MAX_SPEED;
	}
	if (tha_playa->right)
	{
		tha_playa->x += (int)PLAYER_MAX_SPEED;
	}
	// The angle of the texture should now NOT be determined any longer
	// just by player coordinates, but also reflect the fact that the
	// player is forced to keep the center of the viewport.
	// Note that the viewport remains static and so does the player.
	// The game world however is scrolled underneath the viewport:
	// Therefore:
	// tha_playa->x - topleft->x ALWAYS equals (SCREEN_WIDTH / 2)
	// Implication: you'll always compute the angle of the player 
	// texture relative to the same position. I.e. coordinate
	// ((SCREEN_WIDTH / 2), (SCREEN_HEIGTH / 2)), the center of the 
	// pixel coordinate system.
	// Mouse coordinates are also in pixel coordinates and therefore 
	// always have a value between x = 0 ... SCREEN_WIDTH and 
	// y = 0 ... SCREEN_HEIGTH.
	// This way, the angle is always right:
	tha_playa->angle = get_angle(tha_playa->x - topleft->x, 
		tha_playa->y - topleft->y, tha_mouse->x, tha_mouse->y);
}

void proper_shutdown(void)
{
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();
}

// Easter Egg #1 in the `Engineering C Programs' course:
// This function is a horrible idea. Why?
SDL_Texture *load_texture(char *filename)
{
	SDL_Texture *txtr;
	txtr = IMG_LoadTexture(renderer, filename);
	return txtr;
}

void blit(SDL_Texture *txtr, int x, int y, int center)
{
	SDL_Rect dest;
	dest.x = x;
	dest.y = y;
	SDL_QueryTexture(txtr, NULL, NULL, &dest.w, &dest.h);
	if (center)
	{
		dest.x -= dest.w / 2;
		dest.y -= dest.h / 2;
	}
	SDL_RenderCopy(renderer, txtr, NULL, &dest);
}

void blit_angled(SDL_Texture *txtr, int x, int y, float angle)
{
	SDL_Rect dest;
	dest.x = x;
	dest.y = y;
	SDL_QueryTexture(txtr, NULL, NULL, &dest.w, &dest.h);
	dest.x -= (dest.w / 2);
	dest.y -= (dest.h / 2);
	// SDL_RenderCopyEx - SIDENOTE:
	// When drawing, a negative angle means rotating COUNTER-CLOCKWISE
	// and a positive angle means rotating CLOCKWISE.
	SDL_RenderCopyEx(renderer, txtr, NULL, &dest, angle, NULL, 
		SDL_FLIP_NONE);
}

float get_angle(int x1, int y1, int x2, int y2)
{
	// atan2(): a function from math.h, representing the tangent angle:
	// https://en.wikipedia.org/wiki/Atan2
	// where x1,y1 are player coords and x2,y2 are mouse coords.
	// The origin in the wikipedia picture thus represents the player,
	// the (x,y)-pair the mouse coords.
	// The (180.0 / PI) represents 1 radian in degrees, i.e. we're 
	// converting from radians (the output of atan2()) to degrees.
	return (float)(atan2(y2 - y1, x2 - x1) * (180.0 / PI));
	// ATAN2 - SIDENOTE:
	// "The atan2() function returns a value in the range 
	//  -π to π radians"
	// If first arg (delta-y) is POSTIVE, you get a POSITIVE angle
	// between +0.0000...1 and +180 degrees
	// If first arg (delta-y) is NEGATIVE, you get a NEGATIVE angle
	// between 0 and -179.9999...9 degrees
}

// This is a new function whose sole job it is to update the top left
// world coordinate based om the player's world coordinate:
void handle_camera(SDL_Point *topleft, player *tha_playa)
{
	topleft->x = tha_playa->x - (SCREEN_WIDTH / 2);
	topleft->y = tha_playa->y - (SCREEN_HEIGHT / 2);
}

// This is a new function that updates WHAT IS VISIBLE IN THE VIEWPORT
// given the updated topleft-reference point (in `world coordinates')
// and the viewport's size limits:
void draw_viewport(SDL_Texture *txtr_bg_repeat, SDL_Point *topleft)
{
	int x, y, draw_first_x, draw_first_y, draw_last_x, draw_last_y;
	
	// The draw_first/last_x/y variables should hold the values of the
	// x and y `pixel coordinates' where the game should start and stop
	// drawing background tiles. Should be as easy as determining the
	// coordinate of the topleft x/y pixels and drawing tiles for at
	// least as wide and high as the viewport width/height.
	// This line of reasoning is incomplete however. How?
	
	// Consider this: the general idea of this function is that 
	// the viewport itself remains static. You'll always have the 
	// origin (0,0) of the `pixel coordinate system' in the top left 
	// corner. Using just pixel coordinates, you can't keep track of 
	// where the player (and other objects) are in the `game world'.
	// Therefore, we keep track of the player's `world coordinates' 
	// (player.x and player.y) and the top-left reference point (also
	// in `world coordinates'). This way we can ALWAYS MAP THAT PART
	// OF THE GAMEWORLD to the viewport. Think about this for a while.
	// It means the `topleft' variable is in a DIFFERENT coordinate
	// system than the one we're drawing in below ...
	
	// Let me help you get your head around this:
	// To move to the right (positive) is to scroll the 
	// `background-world' to the left (negative).
	// To be very specific: if the top left world coordinate has x=150,
	// this means that the first 150 pixels TO THE LEFT of that mark 
	// fall OUTSIDE OF THE VIEWPORT.
	// AKA, you can start drawing the texture at pixel coordinate
	// x = -150 OUTSIDE the visible area (that's where the `* -1' 
	// comes from in the code below).
	
	draw_first_x = (topleft->x % TILE_SIZE_IN_PIXELS) * -1;
	draw_last_x = draw_first_x + 
		(VIEWPORT_WIDTH_IN_TILES * TILE_SIZE_IN_PIXELS);
	draw_first_y = (topleft->y % TILE_SIZE_IN_PIXELS) * -1;
	draw_last_y = draw_first_y + 
		(VIEWPORT_HEIGHT_IN_TILES * TILE_SIZE_IN_PIXELS);
	
	for (y = draw_first_y; y < draw_last_y; y += TILE_SIZE_IN_PIXELS)
	{
		for (x = draw_first_x; x < draw_last_x; x += TILE_SIZE_IN_PIXELS)
		{
			blit(txtr_bg_repeat, x, y, 0);
		}
	}
}
